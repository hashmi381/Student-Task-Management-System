<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PageController extends Controller
{
    public function about()
    {
        return "This is the about page";
    }
    public function contact()
    {
        return "This is the contact page";
    }
    public function services()
    {
        return "This is the services page";
    }
    public function store(Request $request)
    {
        $tasks = session()->get('tasks', []);
        $filePath = null;

        if ($request->hasFile('attachment')) {
            $filePath = $request->file('attachment')->store('attachments', 'public');
        }

        $tasks[] = [
            'id' => uniqid(),
            'title' => $request->title,
            'description' => $request->description,
            'completed' => false,
            'attachment' => $filePath
        ];

        session()->put('tasks', $tasks);

        return redirect('/tasks');
    }
    public function delete($id)
    {
        $tasks = session()->get('tasks', []);

        $tasks = array_filter($tasks, function ($task) use ($id) {
            return $task['id'] != $id;
        });

        session()->put('tasks', array_values($tasks));

        return redirect('/tasks');
    }
    public function tasks()
    {
        $tasks = session()->get('tasks', []);

        foreach ($tasks as &$task) {
            if (!isset($task['id'])) {
                $task['id'] = uniqid();
            }
        }

        session()->put('tasks', $tasks);

        return view('tasks', compact('tasks'));
    }
    public function edit($id)
    {
        $tasks = session()->get('tasks', []);

        foreach ($tasks as $task) {
            if ($task['id'] == $id) {
                return view('edit-task', compact('task'));
            }
        }

        return redirect('/tasks');
    }
    public function update(Request $request, $id)
    {
        $tasks = session()->get('tasks', []);

        foreach ($tasks as &$task) {
            if ($task['id'] == $id) {
                $task['title'] = $request->title;
                $task['description'] = $request->description;
            }
        }

        session()->put('tasks', $tasks);

        return redirect('/tasks');
    }
    public function complete($id)
    {
        $tasks = session()->get('tasks', []);

        foreach ($tasks as &$task) {
            if ($task['id'] == $id) {
                $task['completed'] = true;
            }
        }

        session()->put('tasks', $tasks);

        return redirect('/tasks');
    }
    public function show($id)
    {
        $tasks = session()->get('tasks', []);

        foreach ($tasks as $task) {
            if ($task['id'] == $id) {
                return view('task-details', compact('task'));
            }
        }

        return redirect('/tasks');
    }
}
